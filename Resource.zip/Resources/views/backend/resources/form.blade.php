<div class="row">
    <!-- Department Name - Now as text input -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'department_name';
            $field_lable = __('Department Name');
            $field_placeholder = 'Enter department name (e.g., Computer Science, Business Administration)';
            $required = 'required';
            
            // Safe way to get field value
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->text($field_name)->value($field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
            <small class="form-text text-muted">Enter the department name (e.g., Computer Science, Business Administration, Engineering, etc.)</small>
        </div>
    </div>

    <!-- Program Level -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'program_level';
            $field_lable = __('Program Level');
            $field_placeholder = '-- Select Program Level --';
            $required = 'required';
            $select_options = \App\Enums\ProgramProgramLevelEnum::asSelectArray();
            
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, $select_options, $field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
            <small class="form-text text-muted">Select the academic program level</small>
        </div>
    </div>

    <!-- Institution Type -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'institution_type';
            $field_lable = __('Institution Type');
            $field_placeholder = '-- Select Institution Type --';
            $required = 'required';
            $select_options = \App\Enums\InstituteTypeEnum::asSelectArray();
            
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, $select_options, $field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
            <small class="form-text text-muted">HEI - Universities and Colleges | TVET - Technical and Vocational Institutions</small>
        </div>
    </div>

    <!-- Accreditation Scope -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'accreditation_scope';
            $field_lable = __('Accreditation Scope');
            $field_placeholder = '-- Select Accreditation Scope --';
            $required = 'required';
            $select_options = [
                'Program Level' => 'Program Level Accreditation',
                'Institutional' => 'Institutional Accreditation'
            ];
            
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, $select_options, $field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
            <small class="form-text text-muted">
                <strong>Program Level:</strong> Specific to individual programs<br>
                <strong>Institutional:</strong> Institution-wide standards
            </small>
        </div>
    </div>

    <!-- Document Type -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'document_type';
            $field_lable = __('Document Type');
            $field_placeholder = '-- Select Document Type --';
            $required = 'required';
            $select_options = [
                'Data Collection Tool' => 'Data Collection Tool',
                'Self Evaluation Report' => 'Self Evaluation Report',
                'Student Satisfaction Survey' => 'Student Satisfaction Survey'
            ];
            
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, $select_options, $field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
            <small class="form-text text-muted">Select the type of document</small>
        </div>
    </div>

    <!-- Status -->
    <div class="col-12 col-sm-6 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'status';
            $field_lable = __('Status');
            $field_placeholder = __('Select an option');
            $required = 'required';
            $select_options = \Modules\Resource\Enums\ResourceStatus::toArray();
            
            $field_value = '';
            if (isset($$module_name_singular) && property_exists($$module_name_singular, $field_name)) {
                $field_value = $$module_name_singular->$field_name;
            } else {
                $field_value = old($field_name);
            }
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, $select_options, $field_value)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
        </div>
    </div>

    <!-- Hidden Slug Field -->
    {{ html()->hidden('slug')->value(isset($$module_name_singular) ? $$module_name_singular->slug : '') }}

    <!-- File Upload -->
    <div class="col-12 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'file';
            $field_lable = __('Upload PDF Document');
            $field_placeholder = $field_lable;
            
            // File is required only for create, optional for edit
            $is_edit = isset($$module_name_singular);
            $required = $is_edit ? '' : 'required';
            ?>
            {{ html()->label($field_lable, $field_name)->class('form-label')->for($field_name) }}
            @if(!$is_edit)
                {!! field_required($required) !!}
            @endif
            {{ html()->file($field_name)->class('form-control')->attributes([$required, 'accept' => 'application/pdf']) }}
            <small class="form-text text-muted">
                Maximum file size: 30MB | Allowed format: PDF only
                @if($is_edit && $$module_name_singular->getFirstMedia('resources'))
                    <br>
                    <div class="mt-2 p-2 bg-light rounded">
                        <strong>Current file:</strong> 
                        <a href="{{ $$module_name_singular->getFirstMediaUrl('resources') }}" target="_blank" class="btn btn-sm btn-outline-primary ms-2">
                            <i class="fas fa-eye"></i> View Current PDF
                        </a>
                        <br>
                        <small class="text-muted">Leave empty to keep the current file</small>
                    </div>
                @else
                    <br><small class="text-muted">PDF file is required for new resources</small>
                @endif
            </small>
        </div>
    </div>
</div>

<!-- Auto-generated Name Preview -->
<div class="row">
    <div class="col-12">
        <div class="alert alert-warning">
            <h6 class="alert-heading"><i class="fas fa-info-circle"></i> Auto-generated Resource Name</h6>
            <hr>
            <p class="mb-0" id="resourceNamePreview">
                @if(isset($$module_name_singular))
                    <strong>Current Name:</strong> {{ $$module_name_singular->name }}
                @else
                    <strong>Preview:</strong> Resource name will be auto-generated based on your selections
                @endif
            </p>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="alert alert-info">
            <h6 class="alert-heading"><i class="fas fa-info-circle"></i> Resource Classification</h6>
            <hr>
            <p class="mb-2">This classification helps organize resources by:</p>
            <ul class="mb-0">
                <li><strong>Department:</strong> Which academic department this resource belongs to</li>
                <li><strong>Program Level:</strong> The academic level of the program</li>
                <li><strong>Institution Type:</strong> Type of educational institution</li>
                <li><strong>Accreditation Scope:</strong> Whether it's program-specific or institution-wide</li>
                <li><strong>Document Type:</strong> The purpose and nature of the document</li>
            </ul>
        </div>
    </div>
</div>

<!-- JavaScript for real-time name preview -->
@push('after-scripts')
<script>
document.addEventListener('DOMContentLoaded', function() {
    const departmentInput = document.querySelector('[name="department_name"]');
    const programLevelSelect = document.querySelector('[name="program_level"]');
    const institutionTypeSelect = document.querySelector('[name="institution_type"]');
    const accreditationScopeSelect = document.querySelector('[name="accreditation_scope"]');
    const documentTypeSelect = document.querySelector('[name="document_type"]');
    const previewElement = document.getElementById('resourceNamePreview');
    
    function updateResourceNamePreview() {
        const department = departmentInput ? departmentInput.value.trim() : '';
        const programLevel = programLevelSelect ? programLevelSelect.options[programLevelSelect.selectedIndex]?.text : '';
        const institutionType = institutionTypeSelect ? institutionTypeSelect.options[institutionTypeSelect.selectedIndex]?.text : '';
        const accreditationScope = accreditationScopeSelect ? accreditationScopeSelect.options[accreditationScopeSelect.selectedIndex]?.text : '';
        const documentType = documentTypeSelect ? documentTypeSelect.options[documentTypeSelect.selectedIndex]?.text : '';
        
        const values = [
            documentType,
            department,
            institutionType,
            accreditationScope,
            programLevel
        ].filter(value => value && !value.includes('Select') && value.trim() !== '');
        
        if (values.length === 5) {
            previewElement.innerHTML = `<strong>Preview:</strong> ${values.join(' - ')}`;
        } else {
            previewElement.innerHTML = `<strong>Preview:</strong> Resource name will be auto-generated based on your selections`;
        }
    }
    
    // Add event listeners
    if (departmentInput) {
        departmentInput.addEventListener('input', updateResourceNamePreview);
    }
    if (programLevelSelect) {
        programLevelSelect.addEventListener('change', updateResourceNamePreview);
    }
    if (institutionTypeSelect) {
        institutionTypeSelect.addEventListener('change', updateResourceNamePreview);
    }
    if (accreditationScopeSelect) {
        accreditationScopeSelect.addEventListener('change', updateResourceNamePreview);
    }
    if (documentTypeSelect) {
        documentTypeSelect.addEventListener('change', updateResourceNamePreview);
    }
    
    // Initial update
    updateResourceNamePreview();
});
</script>
@endpush