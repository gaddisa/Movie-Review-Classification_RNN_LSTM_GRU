@extends('frontend.layouts.app')

@section('title')
    {{ __($module_title) }}
@endsection

@section('content')
    <!-- Hero Section -->
    <section class="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-12">
        <div class="container mx-auto px-6 text-center">
            <div class="max-w-4xl mx-auto">
                <h1 class="text-4xl font-bold sm:text-5xl mb-4">
                    {{ __($module_title) }}
                </h1>
                <p class="text-xl sm:text-2xl mb-6 opacity-95">
                    Access comprehensive accreditation resources including Data Collection Tools, Student Satisfaction Surveys, and Self Evaluation Reports
                </p>
                <div class="flex flex-wrap justify-center gap-4 mt-6">
                    <div class="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-full text-sm">
                        <i class="fas fa-file-contract mr-2"></i>Data Collection Tools
                    </div>
                    <div class="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-full text-sm">
                        <i class="fas fa-clipboard-check mr-2"></i>Self Evaluation Reports
                    </div>
                    <div class="bg-blue-500 bg-opacity-30 px-4 py-2 rounded-full text-sm">
                        <i class="fas fa-user-graduate mr-2"></i>Student Surveys
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Stats Section -->

    <!-- Filters and Search Section -->
    <section class="bg-gray-50 py-8">
        <div class="container mx-auto px-6">
            <div class="bg-white rounded-xl shadow-sm p-6 mb-6">
                <div class="flex flex-col md:flex-row gap-4 items-center justify-between">
                    <!-- Search Input -->
                    <div class="flex-1 w-full md:w-auto">
                        <div class="relative">
                            <i class="fas fa-search absolute left-3 top-3 text-gray-400"></i>
                            <input 
                                type="text" 
                                id="searchInput" 
                                placeholder="Search by name, department, document type..." 
                                class="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200"
                            >
                        </div>
                    </div>

                    <!-- Quick Filters -->
                    <div class="flex flex-wrap gap-2">
                        <button class="filter-btn active px-4 py-2 bg-blue-600 text-white rounded-lg text-sm transition-all duration-200" data-filter="all">
                            All Resources
                        </button>
                        <button class="filter-btn px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-300 transition-all duration-200" data-filter="Data Collection Tool">
                            Data Tools
                        </button>
                        <button class="filter-btn px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-300 transition-all duration-200" data-filter="Self Evaluation Report">
                            Evaluation Reports
                        </button>
                        <button class="filter-btn px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm hover:bg-gray-300 transition-all duration-200" data-filter="Student Satisfaction Survey">
                            Student Surveys
                        </button>
                    </div>
                </div>
            </div>

            <!-- Resources Table -->
            <div class="bg-white rounded-xl shadow-sm overflow-hidden">
                <div class="overflow-x-auto">
                    <table class="w-full text-left" id="resourcesTable">
                        <thead class="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
                            <tr>
                                <th class="p-4 font-semibold">Resource Name</th>
                                <th class="p-4 font-semibold">Department</th>
                                <th class="p-4 font-semibold">Program Level</th>
                                <th class="p-4 font-semibold">Institution Type</th>
                                <th class="p-4 font-semibold">Scope</th>
                                <th class="p-4 font-semibold">Document Type</th>
                                <th class="p-4 font-semibold">Status</th>
                                <th class="p-4 font-semibold text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($$module_name as $$module_name_singular)
                                <tr class="border-b hover:bg-blue-50 transition-all duration-300" data-document-type="{{ $$module_name_singular->document_type }}">
                                    <!-- Resource Name -->
                                    <td class="p-4">
                                        <div class="flex items-center">
                                            <div class="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-lg flex items-center justify-center mr-3">
                                                @if($$module_name_singular->document_type === 'Data Collection Tool')
                                                    <i class="fas fa-file-contract text-blue-600 text-sm"></i>
                                                @elseif($$module_name_singular->document_type === 'Self Evaluation Report')
                                                    <i class="fas fa-clipboard-check text-amber-600 text-sm"></i>
                                                @else
                                                    <i class="fas fa-user-graduate text-cyan-600 text-sm"></i>
                                                @endif
                                            </div>
                                            <div>
                                                <div class="font-semibold text-gray-800">
                                                    {{ $$module_name_singular->name }}
                                                </div>
                                                <div class="text-xs text-gray-500 mt-1">
                                                    Updated {{ $$module_name_singular->updated_at->diffForHumans() }}
                                                </div>
                                            </div>
                                        </div>
                                    </td>

                                    <!-- Department -->
                                    <td class="p-4 text-gray-700 font-medium">
                                        {{ $$module_name_singular->department_name }}
                                    </td>

                                    <!-- Program Level -->
                                    <td class="p-4">
                                        <span class="inline-flex items-center px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                                            <i class="fas fa-graduation-cap mr-1"></i>
                                            {{ $$module_name_singular->program_level }}
                                        </span>
                                    </td>

                                    <!-- Institution Type -->
                                    <td class="p-4">
                                        @if($$module_name_singular->institution_type === 'HEI')
                                            <span class="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-university mr-1"></i>
                                                HEI
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-3 py-1 bg-orange-100 text-orange-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-tools mr-1"></i>
                                                TVET
                                            </span>
                                        @endif
                                    </td>

                                    <!-- Accreditation Scope -->
                                    <td class="p-4">
                                        @if($$module_name_singular->accreditation_scope === 'Program Level')
                                            <span class="inline-flex items-center px-3 py-1 bg-purple-100 text-purple-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-bullseye mr-1"></i>
                                                Program Level
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-3 py-1 bg-indigo-100 text-indigo-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-building mr-1"></i>
                                                Institutional
                                            </span>
                                        @endif
                                    </td>

                                    <!-- Document Type -->
                                    <td class="p-4">
                                        @if($$module_name_singular->document_type === 'Data Collection Tool')
                                            <span class="inline-flex items-center px-3 py-1 bg-teal-100 text-teal-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-file-contract mr-1"></i>
                                                Data Collection
                                            </span>
                                        @elseif($$module_name_singular->document_type === 'Self Evaluation Report')
                                            <span class="inline-flex items-center px-3 py-1 bg-amber-100 text-amber-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-clipboard-check mr-1"></i>
                                                Self Evaluation
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-3 py-1 bg-cyan-100 text-cyan-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-user-graduate mr-1"></i>
                                                Student Survey
                                            </span>
                                        @endif
                                    </td>

                                    <!-- Status -->
                                    <td class="p-4">
                                        @if($$module_name_singular->status === 'Published')
                                            <span class="inline-flex items-center px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-check-circle mr-1"></i>
                                                Published
                                            </span>
                                        @else
                                            <span class="inline-flex items-center px-3 py-1 bg-yellow-100 text-yellow-800 rounded-full text-xs font-medium">
                                                <i class="fas fa-clock mr-1"></i>
                                                Draft
                                            </span>
                                        @endif
                                    </td>

                                    <!-- Download Link -->
                                    <td class="p-4 text-center">
                                        @if ($$module_name_singular->media_url)
                                            <a href="{{ $$module_name_singular->media_url }}" 
                                               download="{{ $$module_name_singular->file_name ?? 'document.pdf' }}"
                                               class="inline-flex items-center px-4 py-2 bg-gradient-to-r from-blue-600 to-blue-700 text-white rounded-lg hover:from-blue-700 hover:to-blue-800 transition-all duration-300 shadow-sm hover:shadow-md transform hover:-translate-y-0.5">
                                                <i class="fas fa-download mr-2"></i> Download
                                            </a>
                                        @else
                                            <span class="inline-flex items-center px-3 py-2 text-gray-400 text-sm" title="No document available">
                                                <i class="fas fa-exclamation-circle mr-1"></i> Not Available
                                            </span>
                                        @endif
                                    </td>
                                </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>

                <!-- Empty State -->
                <div id="emptyState" class="hidden p-12 text-center">
                    <div class="max-w-md mx-auto">
                        <i class="fas fa-search text-gray-300 text-5xl mb-4"></i>
                        <h3 class="text-lg font-semibold text-gray-600 mb-2">No resources found</h3>
                        <p class="text-gray-500">Try adjusting your search or filter criteria</p>
                    </div>
                </div>
            </div>

            <!-- Pagination -->
            <div class="mt-8 flex justify-center">
                {{ $$module_name->links() }}
            </div>
        </div>
    </section>

    <!-- Information Section -->
    <section class="bg-white py-12">
        <div class="container mx-auto px-6">
            <div class="text-center mb-8">
                <h2 class="text-3xl font-bold text-gray-800 mb-4">Understanding Accreditation Resources</h2>
                <p class="text-gray-600 max-w-2xl mx-auto">Our comprehensive collection of accreditation tools and templates designed to support educational institutions in their quality assurance processes.</p>
            </div>

            <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                <!-- Document Types Info -->
                <div class="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-blue-600 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-file-alt text-white text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-blue-800">Document Types</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-start">
                            <i class="fas fa-file-contract text-blue-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-blue-800">Data Collection Tool:</strong>
                                <p class="text-blue-700 text-sm">Templates and forms for gathering comprehensive institutional data</p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-clipboard-check text-amber-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-blue-800">Self Evaluation Report:</strong>
                                <p class="text-blue-700 text-sm">Guidelines and templates for institutional self-assessment</p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-user-graduate text-cyan-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-blue-800">Student Satisfaction Survey:</strong>
                                <p class="text-blue-700 text-sm">Tools for measuring and analyzing student feedback</p>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Accreditation Scope Info -->
                <div class="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-green-600 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-target text-white text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-green-800">Accreditation Scope</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-start">
                            <i class="fas fa-bullseye text-purple-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-green-800">Program Level:</strong>
                                <p class="text-green-700 text-sm">Standards and templates specific to individual academic programs</p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-building text-indigo-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-green-800">Institutional:</strong>
                                <p class="text-green-700 text-sm">Comprehensive institution-wide standards and policies</p>
                            </div>
                        </li>
                    </ul>
                </div>

                <!-- Institution Types Info -->
                <div class="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                    <div class="flex items-center mb-4">
                        <div class="w-12 h-12 bg-purple-600 rounded-lg flex items-center justify-center mr-4">
                            <i class="fas fa-university text-white text-xl"></i>
                        </div>
                        <h3 class="text-xl font-semibold text-purple-800">Institution Types</h3>
                    </div>
                    <ul class="space-y-3">
                        <li class="flex items-start">
                            <i class="fas fa-university text-green-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-purple-800">HEI:</strong>
                                <p class="text-purple-700 text-sm">Higher Education Institutions including Universities and Colleges</p>
                            </div>
                        </li>
                        <li class="flex items-start">
                            <i class="fas fa-tools text-orange-600 mt-1 mr-3"></i>
                            <div>
                                <strong class="text-purple-800">TVET:</strong>
                                <p class="text-purple-700 text-sm">Technical and Vocational Education & Training Institutions</p>
                            </div>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <!-- JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('searchInput');
            const filterButtons = document.querySelectorAll('.filter-btn');
            const tableRows = document.querySelectorAll('#resourcesTable tbody tr');
            const emptyState = document.getElementById('emptyState');
            const tableBody = document.querySelector('#resourcesTable tbody');

            function filterResources() {
                const searchTerm = searchInput.value.toLowerCase();
                const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;
                let visibleRows = 0;

                tableRows.forEach(row => {
                    const rowText = row.innerText.toLowerCase();
                    const documentType = row.dataset.documentType;
                    
                    const matchesSearch = rowText.includes(searchTerm);
                    const matchesFilter = activeFilter === 'all' || documentType === activeFilter;
                    
                    if (matchesSearch && matchesFilter) {
                        row.style.display = '';
                        visibleRows++;
                    } else {
                        row.style.display = 'none';
                    }
                });

                // Show/hide empty state
                if (visibleRows === 0) {
                    emptyState.classList.remove('hidden');
                    tableBody.style.display = 'none';
                } else {
                    emptyState.classList.add('hidden');
                    tableBody.style.display = '';
                }
            }

            // Search functionality
            searchInput.addEventListener('input', filterResources);

            // Filter button functionality
            filterButtons.forEach(button => {
                button.addEventListener('click', function() {
                    filterButtons.forEach(btn => {
                        btn.classList.remove('active', 'bg-blue-600', 'text-white');
                        btn.classList.add('bg-gray-200', 'text-gray-700');
                    });
                    
                    this.classList.add('active', 'bg-blue-600', 'text-white');
                    this.classList.remove('bg-gray-200', 'text-gray-700');
                    
                    filterResources();
                });
            });

            // Initialize
            filterResources();
        });
    </script>

    <style>
        /* Enhanced responsive table styles */
        @media (max-width: 1024px) {
            #resourcesTable {
                display: block;
                overflow-x: auto;
            }
        }

        @media (max-width: 768px) {
            #resourcesTable thead {
                display: none;
            }
            
            #resourcesTable tbody tr {
                display: block;
                margin-bottom: 1.5rem;
                border: 1px solid #e5e7eb;
                border-radius: 0.75rem;
                padding: 1rem;
                background: white;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);
            }
            
            #resourcesTable tbody td {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 0.75rem 0;
                border-bottom: 1px solid #f3f4f6;
                text-align: right;
            }
            
            #resourcesTable tbody td::before {
                content: attr(data-label);
                font-weight: 600;
                text-transform: uppercase;
                font-size: 0.75rem;
                color: #6b7280;
                text-align: left;
            }
            
            #resourcesTable tbody td:last-child {
                border-bottom: none;
                justify-content: center;
            }

            /* Add data labels for mobile */
            #resourcesTable tbody td:nth-child(1)::before { content: "Resource Name"; }
            #resourcesTable tbody td:nth-child(2)::before { content: "Department"; }
            #resourcesTable tbody td:nth-child(3)::before { content: "Program Level"; }
            #resourcesTable tbody td:nth-child(4)::before { content: "Institution Type"; }
            #resourcesTable tbody td:nth-child(5)::before { content: "Scope"; }
            #resourcesTable tbody td:nth-child(6)::before { content: "Document Type"; }
            #resourcesTable tbody td:nth-child(7)::before { content: "Status"; }
            #resourcesTable tbody td:nth-child(8)::before { content: "Action"; }
        }

        /* Smooth animations */
        .filter-btn {
            transition: all 0.3s ease;
        }

        #resourcesTable tbody tr {
            transition: all 0.3s ease;
        }

        /* Custom scrollbar for table */
        .overflow-x-auto::-webkit-scrollbar {
            height: 6px;
        }

        .overflow-x-auto::-webkit-scrollbar-track {
            background: #f1f1f1;
            border-radius: 3px;
        }

        .overflow-x-auto::-webkit-scrollbar-thumb {
            background: #c1c1c1;
            border-radius: 3px;
        }

        .overflow-x-auto::-webkit-scrollbar-thumb:hover {
            background: #a8a8a8;
        }
    </style>
@endsection