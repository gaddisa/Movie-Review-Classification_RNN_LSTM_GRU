<?php

namespace Modules\Resource\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Response;
use Illuminate\Support\Str;

class ResourcesController extends Controller
{
    public $module_title;

    public $module_name;

    public $module_path;

    public $module_icon;

    public $module_model;

    public function __construct()
    {
        // Page Title
        $this->module_title = 'Resources';

        // module name
        $this->module_name = 'resources';

        // directory path of the module
        $this->module_path = 'resource::frontend';

        // module icon
        $this->module_icon = 'fa-regular fa-sun';

        // module model name, path
        $this->module_model = "Modules\Resource\Models\Resource";
    }

    /**
     * Display a listing of the resource.
     *
     * @return Response
     */
    public function index()
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'List';

        // Fetch data with media and all columns
        $$module_name = $module_model::with('media')->latest()->paginate();

        // Add media URL and all details to each item
        $$module_name->each(function ($item) {
            $media = $item->getFirstMedia('resources');
            if ($media) {
                $item->media_url = $media->getUrl();
                $item->file_name = $media->file_name;
            } else {
                $item->media_url = null;
                $item->file_name = null;
            }
        });

        return view(
            "$module_path.$module_name.index",
            compact('module_title', 'module_name', "$module_name", 'module_icon', 'module_action', 'module_name_singular')
        );
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return Response
     */
    public function show($id)
    {
        $id = decode_id($id);

        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'Show';

        $$module_name_singular = $module_model::with('media')->findOrFail($id);

        // Add media URL
        $media = $$module_name_singular->getFirstMedia('resources');
        if ($media) {
            $$module_name_singular->media_url = $media->getUrl();
            $$module_name_singular->file_name = $media->file_name;
        }

        return view(
            "$module_path.$module_name.show",
            compact('module_title', 'module_name', 'module_icon', 'module_action', 'module_name_singular', "$module_name_singular")
        );
    }
}