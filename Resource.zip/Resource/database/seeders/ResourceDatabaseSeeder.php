<?php

namespace Modules\Resource\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\Resource\Models\Resource;

class ResourceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Disable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
         * Resources Seed
         * ------------------
         */

        // DB::table('resources')->truncate();
        // echo "Truncate: resources \n";

        Resource::factory()->count(20)->create();
        $rows = Resource::all();
        echo " Insert: resources \n\n";

        // Enable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
