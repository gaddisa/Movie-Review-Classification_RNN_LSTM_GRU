<?php

namespace Modules\Resource\Console\Commands;

use Illuminate\Console\Command;

class ResourceCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:ResourceCommand';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Resource Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        return Command::SUCCESS;
    }
}
