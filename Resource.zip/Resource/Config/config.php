<?php

return [
    'name' => 'Resource',
];
