<?php

namespace Modules\Resource\Http\Controllers\Backend;

use Carbon\Carbon;
use App\Authorizable;
use Illuminate\Support\Arr;
use Illuminate\Support\Str;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Yajra\DataTables\DataTables;
use Modules\Resource\Models\Resource;
use RealRashid\SweetAlert\Facades\Alert;
use Modules\Resource\Enums\ResourceStatus;
use App\Http\Controllers\Backend\BackendBaseController;

class ResourcesController extends BackendBaseController
{
    use Authorizable;

    public function __construct()
    {
        // Page Title
        $this->module_title = 'Resources';

        // module name
        $this->module_name = 'resources';

        // directory path of the module
        $this->module_path = 'resource::backend';

        // module icon
        $this->module_icon = 'fa-regular fa-sun';

        // module model name, path
        $this->module_model = "Modules\Resource\Models\Resource";
    }

    /**
     * Override the edit method to ensure proper data is passed
     */
    public function edit($id)
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'Edit';

        $$module_name_singular = $module_model::findOrFail($id);

        logUserAccess($module_title . ' ' . $module_action . ' | Id: ' . $$module_name_singular->id);

        return view(
            "{$module_path}.{$module_name}.edit",
            compact('module_title', 'module_name', 'module_path', 'module_icon', 'module_action', 'module_name_singular', "{$module_name_singular}")
        );
    }

    /**
     * Store the form data
     */
    public function store(Request $request)
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'Store';
        
        // Validate the request
        $validated_data = $request->validate([
            'department_name' => 'required|string|max:255',
            'program_level' => 'required|string|max:255',
            'institution_type' => 'required|string|max:255',
            'accreditation_scope' => 'required|string|max:255',
            'document_type' => 'required|string|max:255',
            'status' => Rule::enum(ResourceStatus::class),
            'file' => 'required|file|mimes:pdf|max:30048',
        ]);

        try {
            $data = Arr::except($validated_data, 'file');
            
            // Auto-generate resource name
            $data['name'] = $this->generateResourceName($data);
            
            // Auto-generate slug
            $data['slug'] = Str::slug($data['name']);

            $$module_name_singular = $module_model::create($data);

            // Attach the file to the document
            if ($request->hasFile('file') && $request->file('file')->isValid()) {
                $$module_name_singular->addMediaFromRequest('file')
                    ->toMediaCollection('resources', 'public');
            }

            Alert::toast('Resource uploaded successfully!', 'success');
            return redirect("admin/{$module_name}");
            
        } catch (\Exception $e) {
            Alert::toast('Error uploading resource: ' . $e->getMessage(), 'error');
            return back()->withInput();
        }
    }

    /**
     * Update the specified resource
     */
    public function update(Request $request, $id)
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'Update';

        // Find the record
        $$module_name_singular = $module_model::findOrFail($id);
        
        // Validate the request
        $validated_data = $request->validate([
            'department_name' => 'required|string|max:255',
            'program_level' => 'required|string|max:255',
            'institution_type' => 'required|string|max:255',
            'accreditation_scope' => 'required|string|max:255',
            'document_type' => 'required|string|max:255',
            'status' => Rule::enum(ResourceStatus::class),
            'file' => 'sometimes|file|mimes:pdf|max:30048',
        ]);

        try {
            $data = Arr::except($validated_data, 'file');
            
            // Auto-generate resource name
            $data['name'] = $this->generateResourceName($data);
            
            // Auto-generate slug
            $data['slug'] = Str::slug($data['name']);

            // Update the record
            $$module_name_singular->update($data);

            // Update the file only if provided
            if ($request->hasFile('file') && $request->file('file')->isValid()) {
                // Remove existing file
                $$module_name_singular->clearMediaCollection('resources');
                
                // Add new file
                $$module_name_singular->addMediaFromRequest('file')
                    ->toMediaCollection('resources', 'public');
            }

            Alert::toast('Resource updated successfully!', 'success');
            return redirect("admin/{$module_name}");
            
        } catch (\Exception $e) {
            Alert::toast('Error updating resource: ' . $e->getMessage(), 'error');
            return back()->withInput();
        }
    }

    /**
     * Generate resource name from form fields
     */
    private function generateResourceName($data)
    {
        $parts = [
            $data['document_type'],
            $data['department_name'],
            $data['institution_type'],
            $data['accreditation_scope'],
            $data['program_level']
        ];
        
        return implode(' - ', $parts);
    }

    /**
     * Override the index_data method
     */
    public function index_data(?array $columns = null, array $additionalButtons = [], array $additionalData = [])
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name;
        $module_path = $this->module_path;
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);

        $module_action = 'List';

        // Only show name, status, updated_at and actions
        $columns = $columns ?? ['id', 'name', 'status', 'updated_at'];

        // Base query
        $data = $module_model::select($columns)->with('media')->orderBy('id', 'asc');

        return Datatables::of($data)
            ->addColumn('action', function ($data) use ($module_name, $additionalButtons, $additionalData) {
                return view('backend.includes.action_column', compact('module_name', 'data', 'additionalButtons', 'additionalData'));
            })
            ->editColumn('name', '<strong>{{$name}}</strong>')
            ->editColumn('status', function($data) {
                if ($data->status === 'Published') {
                    return '<span class="badge bg-success">Published</span>';
                } else if ($data->status === 'Draft') {
                    return '<span class="badge bg-warning text-dark">Draft</span>';
                } else {
                    return '<span class="badge bg-secondary">' . $data->status . '</span>';
                }
            })
            ->editColumn('updated_at', function ($data) {
                if ($data->updated_at) {
                    $diff = Carbon::now()->diffInHours($data->updated_at);
                    if ($diff < 25) {
                        return $data->updated_at->diffForHumans();
                    }
                    return $data->updated_at->isoFormat('llll');
                }
                return 'No Date Available';
            })
            ->rawColumns(['name', 'status', 'action'])
            ->orderColumns(['id'], '-:column $1')
            ->make(true);
    }
}