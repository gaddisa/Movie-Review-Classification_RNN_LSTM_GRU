<?php

namespace Modules\DCT\Models;

use App\Models\BaseModel;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\SoftDeletes;

class DCT extends BaseModel
{
    use HasFactory;
    use SoftDeletes;

    protected $table = 'dcts';

    /**
     * Create a new factory instance for the model.
     *
     * @return \Illuminate\Database\Eloquent\Factories\Factory
     */
    protected static function newFactory()
    {
        return \Modules\DCT\database\factories\DCTFactory::new();
    }
    public function program()
    {
        return $this->belongsTo('Modules\Program\Models\Program', 'program_id');
    }
    public function standards()
    {
        return $this->hasMany(\App\Models\Standard::class, 'dct_id');
    }
}
