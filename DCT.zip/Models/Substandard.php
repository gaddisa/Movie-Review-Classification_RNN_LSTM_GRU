<?php

namespace Modules\DCT\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Substandard extends Model
{
    use HasFactory;
protected $table = 'standards';

    protected $fillable = ['standard_id', 'name', 'description', 'created_by', 'updated_by'];

    public function standard()
    {
        return $this->belongsTo(Standard::class);
    }

    public function indicators()
    {
        return $this->hasMany(Indicator::class);
    }
}
