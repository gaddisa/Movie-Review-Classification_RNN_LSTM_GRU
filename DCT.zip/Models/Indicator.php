<?php

namespace Modules\DCT\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Indicator extends Model
{
    use HasFactory;

    protected $fillable = ['substandard_id', 'name', 'description', 'created_by', 'updated_by'];

    public function substandard()
    {
        return $this->belongsTo(Substandard::class);
    }

    public function questions()
    {
        return $this->hasMany(Question::class);
    }
}
