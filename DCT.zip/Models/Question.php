<?php

namespace Modules\DCT\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Question extends Model
{
    use HasFactory;

    protected $fillable = ['indicator_id', 'question_text', 'description', 'created_by', 'updated_by'];

    public function indicator()
    {
        return $this->belongsTo(Indicator::class);
    }
}
