<?php
namespace Modules\DCT\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Standard extends Model
{
    use HasFactory;

    //protected $fillable = ['dct_id', 'name', 'description', 'created_by', 'updated_by'];

    public function DCT()
    {
    return $this->belongsTo(DCT::class, 'dct_id');
    }

    public function substandards()
    {
        return $this->hasMany(Substandard::class);
    }
}
