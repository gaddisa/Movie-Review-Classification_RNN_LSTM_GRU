<?php

namespace Modules\DCT\Http\Controllers\Backend;

use App\Authorizable;
use Modules\Program\Models\Program;
use App\Http\Controllers\Backend\BackendBaseController;
use Illuminate\Support\Str;


class StandardsController extends BackendBaseController
{
    use Authorizable;

    public $module_title;

    public $module_name;

    public $module_path;

    public $module_icon;

    public $module_model;




    public function __construct()
    {
        // Page Title
        $this->module_title = 'Standards Management';

        // Module name
        $this->module_name = 'dcts';

        // Directory path of the module
        $this->module_path = 'dct::backend';
        $this->module_icon = 'fas fa-tags';

        // Module icon
        $this->module_icon = 'fa-regular fa-sun';

        // Module model name, path
        $this->module_model = "Modules\DCT\Models\Standard";
    }
    public function create(array $additionalData = [])
    {


        // Load post categories
        $programs = Program::pluck('name', 'id')->toArray();
        // Merge categories into additional data
        $additionalData = array_merge($additionalData, [
            'programs' => $programs,
        ]);

        // Call the parent create method with the modified data
        return parent::create($additionalData);
    }
    // Override the index_data method to include additional buttons
    // Override the index_data method to include additional buttons





    public function viewStandardLists($id)
    {
        $module_title = $this->module_title;
        $module_name = $this->module_name; // e.g., "dcts"
        $module_path = "dct::backend.standard"; // Custom namespace for the module
        $module_icon = $this->module_icon;
        $module_model = $this->module_model;
        $module_name_singular = Str::singular($module_name);
        $module_action = 'List';

        // Fetch the data using pagination for the standard table (update the model if needed)
        $$module_name = $module_model::paginate(15);

        logUserAccess($module_title . ' ' . $module_action);

        // Return the view with the necessary data
        return view(
            "{$module_path}.index_datatable",
            compact('module_title', 'module_name', 'module_path', 'module_icon', 'module_name_singular', 'module_action')
        );
    }
}
