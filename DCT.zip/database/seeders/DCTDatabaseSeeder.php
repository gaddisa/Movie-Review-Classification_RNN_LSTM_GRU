<?php

namespace Modules\DCT\database\seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\DCT\Models\DCT;

class DCTDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Disable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=0;');

        /*
         * DCTS Seed
         * ------------------
         */

        // DB::table('dcts')->truncate();
        // echo "Truncate: dcts \n";

        DCT::factory()->count(20)->create();
        $rows = DCT::all();
        echo " Insert: dcts \n\n";

        // Enable foreign key checks!
        DB::statement('SET FOREIGN_KEY_CHECKS=1;');
    }
}
