@extends('backend.layouts.app')

@section('title') 
    {{ __($module_action) }} {{ __($module_title) }}
@endsection

@section('breadcrumbs')
    <x-backend.breadcrumbs>
        <x-backend.breadcrumb-item type="active" icon='{{ $module_icon }}'>{{ __($module_title) }}</x-backend.breadcrumb-item>
    </x-backend.breadcrumbs>
@endsection

@section('content')
    <div class="card">
        <div class="card-body">
            <x-backend.section-header>
                <i class="{{ $module_icon }}"></i> {{ __($module_title) }} <small class="text-muted">{{ __($module_action) }}</small>

                <x-slot name="subtitle">
                    @lang(':module_name Management Dashboard', ['module_name' => Str::title($module_name)])
                </x-slot>
                <x-slot name="toolbar">
                    <x-buttons.cancel />
                </x-slot>
            </x-backend.section-header>

            <hr>

            <div class="row mt-4">
                <div class="col">
                    <form method="POST" action="{{ route('backend.dcts.store') }}">
                        @csrf

                        <div class="row">
                            <div class="col-12 mb-3">
                                <div class="form-group">
                                    <label for="program_id" class="form-label">Select Program <span class="text-danger">*</span></label>
                                    <select name="program_id" id="program_id" class="form-control" required>
                                        <option value="">-- Select a Program --</option>
                                        @foreach($programs as $program)
                                            <option value="{{ $program->id }}" {{ old('program_id') == $program->id ? 'selected' : '' }}>
                                                {{ $program->name }} - {{ $program->description }}
                                            </option>
                                        @endforeach
                                    </select>
                                    <small class="form-text text-muted">
                                        Select the program for which you want to create a DCT (Data Collection Tool). 
                                        The DCT name will be automatically generated based on the program description.
                                    </small>
                                    @error('program_id')
                                        <div class="text-danger">{{ $message }}</div>
                                    @enderror
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="alert alert-info">
                                    <h6 class="alert-heading"><i class="fas fa-info-circle"></i> How DCTs Work</h6>
                                    <hr>
                                    <p class="mb-1"><strong>DCT (Data Collection Tool)</strong> will be automatically created with the format: <code>DCT-{program-description}</code></p>
                                    <p class="mb-0">Once created, you can add standards, substandards, indicators, and questions to organize your accreditation documentation.</p>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col-12">
                                <div class="form-group">
                                    <x-buttons.create title="Create DCT" class="float-end">
                                        {{ __('Create') }} {{ ucwords(Str::singular($module_name)) }}
                                    </x-buttons.create>
                                    <x-buttons.cancel />
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection