<div class="row">
    <!-- Name Field -->
    <div class="col-12 col-sm-4 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'name';
            $field_label = label_case($field_name);
            $field_placeholder = $field_label;
            $required = 'required';
            ?>
            {{ html()->label($field_label, $field_name)->class('form-label') }}
            {!! field_required($required) !!}
            {{ html()->text($field_name)->placeholder($field_placeholder)->class('form-control')->attributes(["$required"]) }}
        </div>
    </div>

    <!-- Program Field -->
    <div class="col-12 col-sm-4 mb-3">
        <div class="form-group">
            <?php
            $field_name = 'program_id';
            $field_label = label_case('program');
            $field_placeholder = __('Select an option');
            $required = 'required';
            ?>
            {{ html()->label($field_label, $field_name)->class('form-label') }}
            {!! field_required($required) !!}
            {{ html()->select($field_name, [])->placeholder($field_placeholder)->class('form-select select2-category')->attributes([$required]) }}
        </div>
    </div>
</div>

<x-library.select2 />
@push('after-scripts')
    <script type="module">
        $(document).ready(function() {
            // Initialize Select2 for Program field
            $('.select2-category').select2({
                theme: 'bootstrap-5',
                placeholder: '@lang('Select an option')',
                minimumInputLength: 2,
                allowClear: true,
                ajax: {
                    url: '{{ route('backend.programs.index_list') }}', // Adjust route accordingly
                    dataType: 'json',
                    delay: 250,
                    data: function(params) {
                        return {
                            q: $.trim(params.term),
                        };
                    },
                    processResults: function(data) {
                        return {
                            results: data,
                        };
                    },
                    cache: true,
                },
            });

            // Focus on the search field when Select2 is opened
            $(document).on('select2:open', () => {
                const searchField = document.querySelector('.select2-search__field');
                if (searchField) searchField.focus();
            });
        });
    </script>
@endpush
